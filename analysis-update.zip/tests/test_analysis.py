"""Analysis tests against a real Postgres: the tagger assigns the rules we
expect, the outlier score is computed correctly (a 3x-median video scores 3.0),
and segmentation keeps niches separate (an AI-tools hit never shows up in
AI-agency patterns).
"""
from __future__ import annotations

from datetime import datetime, timezone

import pytest
from sqlalchemy import text

from src.analysis import attributes as attr
from src.analysis.outlier import score_all
from src.analysis.patterns import what_works
from src.db.session import SessionLocal, engine

AG, TL = "UC_ag_test", "UC_tl_test"


def _seed():
    with engine.begin() as c:
        for cid, niche in [(AG, "ai-agency"), (TL, "ai-tools")]:
            c.execute(text("INSERT INTO channels (channel_id, handle, title, niche) "
                           "VALUES (:i,:i,:i,:n)"), {"i": cid, "n": niche})
        vids = [
            # (id, channel, title, duration, views)
            ("av1", AG, "I Made $12,000 With AI Agents", 800, 300),   # outlier 3.0
            ("av2", AG, "How to Build & Sell AI Agents", 1500, 100),
            ("av3", AG, "Cold Email Tips for Agencies", 600, 100),
            ("av4", AG, "My n8n Automation Workflow", 700, 100),
            ("tv1", TL, "Free AI Tools You Need", 300, 900000),       # tools-lane hit
            ("tv2", TL, "ChatGPT Prompt Guide", 400, 100000),
            ("tv3", TL, "Best AI Apps 2026", 500, 100000),
        ]
        for vid, cid, title, dur, views in vids:
            c.execute(text(
                "INSERT INTO videos (video_id, channel_id, title, published_at, "
                "duration_seconds) VALUES (:v,:c,:t,:p,:d)"),
                {"v": vid, "c": cid, "t": title,
                 "p": datetime(2026, 6, 20, 9, tzinfo=timezone.utc), "d": dur})
            c.execute(text(
                "INSERT INTO metric_snapshots (video_id, captured_at, view_count, source) "
                "VALUES (:v, now(), :w, 'backfill')"), {"v": vid, "w": views})


def _wipe():
    with engine.begin() as c:
        for cid in (AG, TL):
            c.execute(text("DELETE FROM video_performance WHERE video_id IN "
                           "(SELECT video_id FROM videos WHERE channel_id=:c)"), {"c": cid})
            c.execute(text("DELETE FROM video_attributes WHERE video_id IN "
                           "(SELECT video_id FROM videos WHERE channel_id=:c)"), {"c": cid})
            c.execute(text("DELETE FROM metric_snapshots WHERE video_id IN "
                           "(SELECT video_id FROM videos WHERE channel_id=:c)"), {"c": cid})
            c.execute(text("DELETE FROM videos WHERE channel_id=:c"), {"c": cid})
            c.execute(text("DELETE FROM channels WHERE channel_id=:c"), {"c": cid})


@pytest.fixture
def seeded():
    _wipe(); _seed()
    yield
    _wipe()


def test_tagger_rules():
    assert attr.title_mechanic("I Made $12,000 With AI Agents") == "dollar-figure"
    assert attr.title_mechanic("How to Build & Sell AI Agents") == "build-sell"
    assert attr.title_mechanic("5 Tools You Need") == "listicle"
    assert attr.video_format("X", 30) == "short"
    assert attr.video_format("How to build agents", 1500) == "tutorial"
    assert attr.duration_bucket(45) == "short"
    assert attr.duration_bucket(5000) == "course"


def test_outlier_and_segmentation(seeded):
    attr.tag_all()
    score_all()
    session = SessionLocal()

    # av1 has 300 views vs channel median 100 -> outlier 3.0
    score = session.execute(text(
        "SELECT outlier_score FROM video_performance WHERE video_id='av1'")).scalar()
    assert float(score) == 3.0

    # the $ title was tagged dollar-figure
    mech = session.execute(text(
        "SELECT title_mechanic FROM video_attributes WHERE video_id='av1'")).scalar()
    assert mech == "dollar-figure"

    # segmentation: dollar-figure shows up in ai-agency patterns...
    ag = what_works(session, "ai-agency", "title_mechanic", min_n=1)
    assert any(r["value"] == "dollar-figure" for r in ag)

    # ...and the AI-tools channel's videos never appear in the agency segment
    ag_topics = what_works(session, "ai-agency", "topic", min_n=1)
    # tv1 ("Free AI Tools") would be 'general'/'chatgpt' in tools lane; ensure no
    # tools-lane video leaked in by checking agency counts equal agency video count
    total_ag = sum(r["n"] for r in ag_topics)
    assert total_ag == 4
    session.close()
